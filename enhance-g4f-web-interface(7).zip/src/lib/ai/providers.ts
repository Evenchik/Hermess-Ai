import type { StreamEvent } from "../types";

export type UpstreamMessage = { role: string; content: unknown };

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

function* chunkText(text: string, size: number) {
  const chars = Array.from(text);
  for (let i = 0; i < chars.length; i += size) {
    yield chars.slice(i, i + size).join("");
  }
}

const POLLINATION_HEADERS: Record<string, string> = {
  "Content-Type": "application/json",
  Accept: "application/json, text/plain, */*",
  "User-Agent":
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36",
  Referer: "https://text.pollinations.ai/",
  Origin: "https://text.pollinations.ai",
};

async function requestWithTimeout(
  url: string,
  init: RequestInit,
  signal?: AbortSignal,
  timeoutMs = 15_000,
): Promise<Response> {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  const onAbort = () => ctrl.abort();
  signal?.addEventListener("abort", onAbort, { once: true });
  try {
    return await fetch(url, { ...init, signal: ctrl.signal });
  } finally {
    clearTimeout(timer);
    signal?.removeEventListener("abort", onAbort);
  }
}

function extractOpenAiMessage(data: unknown): {
  content: string;
  reasoning: string;
} {
  const d = data as {
    choices?: Array<{
      message?: {
        content?: string;
        reasoning?: string;
        reasoning_content?: string;
      };
    }>;
    message?: {
      content?: string;
      reasoning?: string;
      reasoning_content?: string;
    };
  };
  const msg = d?.choices?.[0]?.message ?? d?.message ?? {};
  return {
    content: typeof msg.content === "string" ? msg.content : "",
    reasoning:
      typeof msg.reasoning === "string"
        ? msg.reasoning
        : typeof msg.reasoning_content === "string"
          ? msg.reasoning_content
          : "",
  };
}

type GenerateResult = { content: string; reasoning: string };

/** Thrown when an upstream provider rate-limits us (with a retry hint). */
class RateLimitError extends Error {
  retryAfterMs: number;
  constructor(message: string, retryAfterMs: number) {
    super(message);
    this.retryAfterMs = retryAfterMs;
  }
}

/** Extracts a "retry after N seconds" hint from a provider error body. */
function detectRetryAfterMs(body: string): number | null {
  const json = (() => {
    try {
      return JSON.parse(body) as Record<string, unknown>;
    } catch {
      return null;
    }
  })();

  if (json) {
    const err = (json.error ?? {}) as Record<string, unknown>;
    const ra = err.retry_after ?? err.retryAfter;
    if (typeof ra === "number" && ra > 0) return ra * 1000;
    const msg = typeof err.message === "string" ? err.message : "";
    const m = /retry after\s+(\d+)/i.exec(msg);
    if (m) return Number(m[1]) * 1000;
  }

  const m = /retry after\s+(\d+)/i.exec(body);
  if (m) return Number(m[1]) * 1000;
  return null;
}

/**
 * Runs a generation attempt `attempts` times. Retries empty-content responses
 * and failures, backing off according to provider rate-limit hints so we don't
 * keep hammering the free tiers.
 */
async function attemptGenerate(
  fn: () => Promise<GenerateResult>,
  attempts: number,
  signal?: AbortSignal,
  baseDelayMs = 1000,
): Promise<GenerateResult | null> {
  for (let i = 0; i < attempts; i++) {
    if (signal?.aborted) return null;

    let delay = baseDelayMs * Math.pow(1.6, i);
    try {
      const r = await fn();
      if (r.content.trim()) return r;
      // Empty content: retry (the provider sometimes returns a blank reply).
    } catch (e) {
      if (e instanceof RateLimitError) {
        delay = Math.max(delay, e.retryAfterMs + 250);
      }
    }
    // Cap the wait so the chat fails fast instead of hanging for tens of
    // seconds when the free tiers are overloaded.
    await sleep(Math.min(delay, 4000));
  }
  return null;
}

function toPromptText(messages: UpstreamMessage[]): string {
  const parts: string[] = [];
  for (const m of messages) {
    const text = Array.isArray(m.content) ? "" : String(m.content ?? "");
    if (!text) continue;
    if (m.role === "system") parts.push(`Инструкция: ${text}`);
    else if (m.role === "user") parts.push(`Пользователь: ${text}`);
    else if (m.role === "assistant") parts.push(`Ассистент: ${text}`);
  }
  return parts.join("\n\n") + "\n\nАссистент:";
}

// Maps our internal model ids to the real LLM7 model ids.
const LLM7_MODEL_MAP: Record<string, string> = {
  "deepseek-v4-flash": "DeepSeek-V4-Flash-0731",
  "openai-fast": "DeepSeek-V4-Flash-0731",
  "gpt-oss-20b": "gpt-oss:20b",
};

async function callLlm7(
  model: string,
  messages: UpstreamMessage[],
  signal?: AbortSignal,
): Promise<GenerateResult> {
  const res = await requestWithTimeout(
    "https://api.llm7.io/v1/chat/completions",
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ model, messages, stream: false }),
    },
    signal,
  );
  const text = await res.text().catch(() => "");
  if (!res.ok) {
    const retryAfter = detectRetryAfterMs(text) ?? 1500;
    throw new RateLimitError(`LLM7 HTTP ${res.status}`, retryAfter);
  }
  return extractOpenAiMessage(JSON.parse(text));
}

async function callPollinationsOpenAi(
  messages: UpstreamMessage[],
  signal?: AbortSignal,
): Promise<GenerateResult> {
  const res = await requestWithTimeout(
    "https://text.pollinations.ai/openai",
    {
      method: "POST",
      headers: POLLINATION_HEADERS,
      body: JSON.stringify({
        model: "openai-fast",
        messages,
        stream: false,
      }),
    },
    signal,
  );
  const text = await res.text().catch(() => "");
  if (!res.ok) {
    const retryAfter = detectRetryAfterMs(text) ?? 2000;
    throw new RateLimitError(`Pollinations HTTP ${res.status}`, retryAfter);
  }
  return extractOpenAiMessage(JSON.parse(text));
}

async function callPollinationsPost(
  messages: UpstreamMessage[],
  signal?: AbortSignal,
): Promise<GenerateResult> {
  const res = await requestWithTimeout(
    "https://text.pollinations.ai/",
    {
      method: "POST",
      headers: POLLINATION_HEADERS,
      body: JSON.stringify({ model: "openai", messages, stream: false }),
    },
    signal,
    10_000,
  );
  const text = await res.text();
  if (!res.ok) {
    const retryAfter = detectRetryAfterMs(text) ?? 2000;
    throw new RateLimitError(`Pollinations POST HTTP ${res.status}`, retryAfter);
  }
  if (text.trim().startsWith("{")) {
    return extractOpenAiMessage(JSON.parse(text));
  }
  return { content: text, reasoning: "" };
}

async function callPollinationsGet(
  messages: UpstreamMessage[],
  signal?: AbortSignal,
): Promise<GenerateResult> {
  const prompt = toPromptText(messages).slice(-1200);
  const res = await requestWithTimeout(
    `https://text.pollinations.ai/${encodeURIComponent(prompt)}`,
    { method: "GET", headers: { "User-Agent": POLLINATION_HEADERS["User-Agent"] } },
    signal,
    8000,
  );
  if (!res.ok) throw new Error(`Pollinations GET HTTP ${res.status}`);
  return { content: await res.text(), reasoning: "" };
}

/**
 * Keyless free tier. Routes the selected model to its real model on LLM7
 * (so "DeepSeek V4 Flash" and "GPT-OSS 20B" are genuinely different models)
 * and simulates a smooth token stream to the UI. Pollinations acts as a
 * fallback when LLM7 is unavailable or rate-limited.
 */
export async function* freeTierStream(opts: {
  model?: string;
  messages: UpstreamMessage[];
  signal?: AbortSignal;
}): AsyncGenerator<StreamEvent> {
  const llm7Model =
    LLM7_MODEL_MAP[opts.model ?? "deepseek-v4-flash"] ?? "DeepSeek-V4-Flash-0731";

  let result: GenerateResult | null = null;

  // 1) Primary: the exact requested model via LLM7.
  result = await attemptGenerate(
    () => callLlm7(llm7Model, opts.messages, opts.signal),
    2,
    opts.signal,
  );

  // 2) Fallback: Pollinations OpenAI-compatible endpoint.
  if (!result && !opts.signal?.aborted) {
    result = await attemptGenerate(
      () => callPollinationsOpenAi(opts.messages, opts.signal),
      1,
      opts.signal,
      1200,
    );
  }

  // 3) Fallback: Pollinations legacy POST.
  if (!result && !opts.signal?.aborted) {
    result = await attemptGenerate(
      () => callPollinationsPost(opts.messages, opts.signal),
      1,
      opts.signal,
    );
  }

  // 4) Fallback: Pollinations legacy GET.
  if (!result && !opts.signal?.aborted) {
    result = await attemptGenerate(
      () => callPollinationsGet(opts.messages, opts.signal),
      1,
      opts.signal,
    );
  }

  if (!result || !result.content.trim()) {
    throw new Error(
      "Сервисы ИИ временно перегружены (лимит запросов). Подождите несколько секунд и попробуйте снова.",
    );
  }

  if (result.reasoning.trim()) {
    for (const chunk of chunkText(result.reasoning, 30)) {
      if (opts.signal?.aborted) return;
      yield { type: "reasoning", delta: chunk };
      await sleep(4);
    }
  }

  for (const chunk of chunkText(result.content, 5)) {
    if (opts.signal?.aborted) return;
    yield { type: "text", delta: chunk };
    await sleep(10);
  }
}

async function* openAiCompatibleStream(opts: {
  url: string;
  apiKey: string;
  model: string;
  messages: UpstreamMessage[];
  signal?: AbortSignal;
}): AsyncGenerator<{ content?: string; reasoning?: string }> {
  const res = await fetch(opts.url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${opts.apiKey}`,
    },
    body: JSON.stringify({ model: opts.model, messages: opts.messages, stream: true }),
    signal: opts.signal,
  });

  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(`Ошибка API (${res.status}): ${text.slice(0, 220)}`);
  }
  if (!res.body) throw new Error("Пустой ответ API.");

  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split("\n");
    buffer = lines.pop() ?? "";

    for (const line of lines) {
      const t = line.trim();
      if (!t.startsWith("data:")) continue;
      const payload = t.slice(5).trim();
      if (!payload || payload === "[DONE]") continue;

      let json: {
        choices?: Array<{ delta?: Record<string, unknown> }>;
      };
      try {
        json = JSON.parse(payload);
      } catch {
        continue;
      }

      const delta = json.choices?.[0]?.delta ?? {};
      const reasoning =
        (delta.reasoning_content as string) ??
        (delta.reasoning as string) ??
        undefined;
      const content = delta.content as string | undefined;

      if (reasoning) yield { reasoning };
      if (content) yield { content };
    }
  }
}

export async function* openaiStream(opts: {
  model: string;
  messages: UpstreamMessage[];
  signal?: AbortSignal;
}): AsyncGenerator<StreamEvent> {
  const gen = openAiCompatibleStream({
    url: "https://api.openai.com/v1/chat/completions",
    apiKey: process.env.OPENAI_API_KEY ?? "",
    model: opts.model,
    messages: opts.messages,
    signal: opts.signal,
  });
  for await (const d of gen) {
    if (d.reasoning) yield { type: "reasoning", delta: d.reasoning };
    if (d.content) yield { type: "text", delta: d.content };
  }
}

export async function* groqStream(opts: {
  model: string;
  messages: UpstreamMessage[];
  signal?: AbortSignal;
}): AsyncGenerator<StreamEvent> {
  const gen = openAiCompatibleStream({
    url: "https://api.groq.com/openai/v1/chat/completions",
    apiKey: process.env.GROQ_API_KEY ?? "",
    model: opts.model,
    messages: opts.messages,
    signal: opts.signal,
  });
  for await (const d of gen) {
    if (d.reasoning) yield { type: "reasoning", delta: d.reasoning };
    if (d.content) yield { type: "text", delta: d.content };
  }
}

export async function* anthropicStream(opts: {
  model: string;
  system: string;
  messages: UpstreamMessage[];
  signal?: AbortSignal;
}): AsyncGenerator<StreamEvent> {
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": process.env.ANTHROPIC_API_KEY ?? "",
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({
      model: opts.model,
      max_tokens: 4096,
      stream: true,
      system: opts.system,
      messages: opts.messages,
    }),
    signal: opts.signal,
  });

  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(`Ошибка Anthropic (${res.status}): ${text.slice(0, 220)}`);
  }
  if (!res.body) throw new Error("Пустой ответ Anthropic.");

  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  let eventName = "";

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split("\n");
    buffer = lines.pop() ?? "";

    for (const line of lines) {
      if (line.startsWith("event:")) {
        eventName = line.slice(6).trim();
        continue;
      }
      if (!line.startsWith("data:")) continue;
      const payload = line.slice(5).trim();
      if (!payload) continue;

      let json: { delta?: { type?: string; text?: string; thinking?: string } };
      try {
        json = JSON.parse(payload);
      } catch {
        continue;
      }

      if (eventName === "content_block_delta") {
        const delta = json.delta ?? {};
        if (delta.type === "text_delta" && delta.text) {
          yield { type: "text", delta: delta.text };
        } else if (delta.type === "thinking_delta" && delta.thinking) {
          yield { type: "reasoning", delta: delta.thinking };
        }
      }
    }
  }
}
